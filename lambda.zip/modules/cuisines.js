module.exports = [
  "thai",
  "sushi",
  "mexican",
  "indian",
  "italian",
  "burgers",
  "pizza",
  "asian fusion",
  "noodles"
];
