module.exports = [
  "Looks like a great night for some ",
  "Let's shake it up a bit, how about some "
];
